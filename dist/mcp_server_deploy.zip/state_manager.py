import json
import logging
import asyncio
from typing import Optional, Any, Dict, List
import redis.asyncio as redis
from datetime import datetime

from .config import Settings

logger = logging.getLogger(__name__)

class StateManager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.redis: Optional[redis.Redis] = None
        self.is_connected = False

    async def connect(self):
        """Initialize connection to Redis"""
        if not self.settings.REDIS_URL:
            logger.warning("No Redis URL provided. State persistence disabled.")
            return

        try:
            self.redis = redis.from_url(
                self.settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True
            )
            await self.redis.ping()
            self.is_connected = True
            logger.info("Connected to Redis")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self.is_connected = False

    async def close(self):
        if self.redis:
            await self.redis.close()
            self.is_connected = False

    async def register_agent(self, agent_id: str, metadata: Dict[str, Any], ttl: int = 300):
        """Register an active agent with a TTL"""
        if not self.is_connected:
            return

        key = f"agent:{agent_id}"
        metadata["last_heartbeat"] = datetime.now().isoformat()
        try:
            await self.redis.set(key, json.dumps(metadata), ex=ttl)
        except Exception as e:
            logger.error(f"Failed to register agent {agent_id}: {e}")

    async def get_active_agents(self) -> List[Dict[str, Any]]:
        """Get all currently active agents"""
        if not self.is_connected:
            return []

        try:
            keys = await self.redis.keys("agent:*")
            if not keys:
                return []
            
            # Using mget for efficiency, but keys is a list of keys
            agents_json = await self.redis.mget(keys)
            agents = []
            for j in agents_json:
                if j:
                    agents.append(json.loads(j))
            return agents
        except Exception as e:
            logger.error("Failed to get active agents: %s", e)
            return []

    async def save_task_state(self, task_id: str, state: Dict[str, Any], ttl: int = 3600):
        """Persist task state/result"""
        if not self.is_connected:
            return

        key = f"task:{task_id}"
        try:
            await self.redis.set(key, json.dumps(state), ex=ttl)
        except Exception as e:
            logger.error(f"Failed to save task state {task_id}: {e}")

    async def get_task_state(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve task state"""
        if not self.is_connected:
            return None

        key = f"task:{task_id}"
        try:
            data = await self.redis.get(key)
            if data:
                return json.loads(data)
            return None
        except Exception as e:
            logger.error(f"Failed to get task state {task_id}: {e}")
            return None
