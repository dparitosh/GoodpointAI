import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple, TYPE_CHECKING
import neo4j
from fastapi import HTTPException

if TYPE_CHECKING:
    from .state_manager import StateManager

from .models import (
    AgentType, TaskType, AgentCapability, AgentDefinition, 
    AgenticTask, AgenticTaskResult, SystemStatus
)

logger = logging.getLogger(__name__)

class AgenticOrchestrator:
    def __init__(self, state_manager: Optional['StateManager'] = None):
        self.state_manager = state_manager
        self.agents: Dict[str, AgentDefinition] = {}
        self.task_queue: List[AgenticTask] = []
        self.active_tasks: Dict[str, AgenticTask] = {}
        self.task_results: Dict[str, AgenticTaskResult] = {}
        self.chat_sessions: Dict[str, List[Dict]] = {}
        self.system_metrics = {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "average_response_time": 0.0,
            "agent_utilization": {}
        }
        self._initialize_agents()

    async def _register_agents_state(self):
        """Register agents with state manager if available"""
        if self.state_manager and self.state_manager.is_connected:
            for agent in self.agents.values():
                await self.state_manager.register_agent(
                    agent.id,
                    agent.model_dump(mode="json"),
                    ttl=300
                )

    def _initialize_agents(self):
        """Initialize all agent definitions with their capabilities"""
        agent_configs = {
            AgentType.DATA_ANALYST: {
                "name": "Data Analysis Agent",
                "capabilities": [
                    AgentCapability(name="analyze_data_patterns", description="Analyze Neo4j graph patterns"),
                    AgentCapability(name="generate_insights", description="Generate analytical insights"),
                    AgentCapability(name="data_quality_assessment", description="Assess data quality"),
                    AgentCapability(name="statistical_analysis", description="Perform statistical analysis")
                ]
            },
            AgentType.ETL_ORCHESTRATOR: {
                "name": "ETL Orchestration Agent", 
                "capabilities": [
                    AgentCapability(name="manage_data_pipelines", description="Manage ETL pipelines"),
                    AgentCapability(name="handle_data_transformations", description="Handle data transformations"),
                    AgentCapability(name="monitor_pipeline_health", description="Monitor pipeline health")
                ]
            },
            AgentType.QUERY_PLANNER: {
                "name": "Query Planning Agent",
                "capabilities": [
                    AgentCapability(name="optimize_graph_queries", description="Optimize Cypher queries"),
                    AgentCapability(name="plan_execution_strategies", description="Plan query execution"),
                    AgentCapability(name="manage_query_cache", description="Manage query caching"),
                    AgentCapability(name="analyze_performance", description="Analyze query performance")
                ]
            },
            AgentType.VISUALIZATION_AGENT: {
                "name": "Visualization Agent",
                "capabilities": [
                    AgentCapability(name="generate_graph_layouts", description="Generate optimal graph layouts"),
                    AgentCapability(name="create_chart_configurations", description="Create chart configurations"),
                    AgentCapability(name="manage_ui_state", description="Manage UI state"),
                    AgentCapability(name="handle_user_interactions", description="Handle user interactions")
                ]
            },
            AgentType.QUALITY_MONITOR: {
                "name": "Quality Monitoring Agent",
                "capabilities": [
                    AgentCapability(name="monitor_data_quality", description="Monitor data quality metrics"),
                    AgentCapability(name="detect_anomalies", description="Detect data anomalies"),
                    AgentCapability(name="validate_transformations", description="Validate data transformations"),
                    AgentCapability(name="generate_quality_reports", description="Generate quality reports")
                ]
            },
            AgentType.CHAT_COORDINATOR: {
                "name": "Chat Coordination Agent",
                "capabilities": [
                    AgentCapability(name="process_natural_language", description="Process natural language"),
                    AgentCapability(name="coordinate_agent_responses", description="Coordinate agent responses"),
                    AgentCapability(name="manage_conversation_context", description="Manage conversation context"),
                    AgentCapability(name="route_user_requests", description="Route user requests")
                ]
            }
        }

        for agent_type, config in agent_configs.items():
            agent_id = f"{agent_type.value}_{int(datetime.now().timestamp())}"
            self.agents[agent_id] = AgentDefinition(
                id=agent_id,
                type=agent_type,
                **config
            )

    async def route_task_to_agent(self, task: AgenticTask) -> Optional[str]:
        """Route task to the most suitable agent"""
        suitable_agents: List[Tuple[str, float]] = []
        
        for agent_id, agent in self.agents.items():
            if agent.status != "ready":
                continue
                
            agent_capabilities = [cap.name for cap in agent.capabilities]
            matching_capabilities = set(task.required_capabilities) & set(agent_capabilities)
            
            if matching_capabilities:
                score = len(matching_capabilities) / len(task.required_capabilities)
                suitable_agents.append((agent_id, score))
        
        if not suitable_agents:
            return None
            
        # Sort by capability match score
        suitable_agents.sort(key=lambda x: x[1], reverse=True)
        return suitable_agents[0][0]

    async def execute_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> AgenticTaskResult:
        """Execute task with assigned agent"""
        agent_id = await self.route_task_to_agent(task)
        
        if not agent_id:
            return AgenticTaskResult(
                task_id=task.id,
                agent_id="none",
                agent_type=AgentType.CHAT_COORDINATOR,
                success=False,
                error="No suitable agent found",
                execution_time=0.0
            )

        agent = self.agents[agent_id]
        start_time = datetime.now()
        
        try:
            # Update agent status
            agent.status = "busy"
            agent.last_activity = start_time
            
            # Execute task based on type
            result = await self._execute_agent_task(task, agent, driver_instance)
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Update metrics
            self.system_metrics["tasks_completed"] += 1
            self._update_performance_metrics(agent_id, execution_time, True)
            
            task_result = AgenticTaskResult(
                task_id=task.id,
                agent_id=agent_id,
                agent_type=agent.type,
                success=True,
                result=result,
                execution_time=execution_time
            )
            self.task_results[task.id] = task_result
            
            # Save to state manager
            if self.state_manager:
                await self.state_manager.save_task_state(task.id, task_result.model_dump(mode="json"))

            return task_result
            
        except (
            neo4j.exceptions.Neo4jError,
            HTTPException,
            OSError,
            RuntimeError,
            ValueError,
            TypeError,
            KeyError,
        ) as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self.system_metrics["tasks_failed"] += 1
            self._update_performance_metrics(agent_id, execution_time, False)
            
            logger.error("Task execution failed for agent %s: %s", agent_id, e)
            
            error_result = AgenticTaskResult(
                task_id=task.id,
                agent_id=agent_id,
                agent_type=agent.type,
                success=False,
                error=str(e),
                execution_time=execution_time
            )
            self.task_results[task.id] = error_result
            
            # Save to state manager
            if self.state_manager:
                await self.state_manager.save_task_state(task.id, error_result.model_dump(mode="json"))

            return error_result
        finally:
            # Reset agent status
            agent.status = "ready"

    def _update_performance_metrics(self, agent_id: str, execution_time: float, success: bool):
        """Update metrics for an agent"""
        if agent_id in self.agents:
            agent = self.agents[agent_id]
            # Simple moving average for execution time
            current_avg = agent.performance_metrics.get("avg_execution_time", 0.0)
            count = agent.performance_metrics.get("task_count", 0)
            
            new_count = count + 1
            new_avg = ((current_avg * count) + execution_time) / new_count
            
            agent.performance_metrics["avg_execution_time"] = new_avg
            agent.performance_metrics["task_count"] = new_count
            
            if success:
                agent.performance_metrics["success_count"] = agent.performance_metrics.get("success_count", 0) + 1
            else:
                agent.performance_metrics["fail_count"] = agent.performance_metrics.get("fail_count", 0) + 1

    async def _execute_agent_task(self, task: AgenticTask, agent: AgentDefinition, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
        """Execute specific agent task based on agent type and task type"""
        
        if agent.type == AgentType.DATA_ANALYST:
            return await self._execute_data_analysis_task(task, driver_instance)
        elif agent.type == AgentType.ETL_ORCHESTRATOR:
            return await self._execute_etl_task(task, driver_instance)
        elif agent.type == AgentType.QUERY_PLANNER:
            return await self._execute_query_planning_task(task, driver_instance)
        elif agent.type == AgentType.VISUALIZATION_AGENT:
            return await self._execute_visualization_task(task, driver_instance)
        elif agent.type == AgentType.QUALITY_MONITOR:
            return await self._execute_quality_monitoring_task(task, driver_instance)
        elif agent.type == AgentType.CHAT_COORDINATOR:
            return await self._execute_chat_coordination_task(task, driver_instance)
        else:
            raise ValueError(f"Unknown agent type: {agent.type}")

    # Placeholder methods for extracted logic
    # In a full migration, these would be moved to their own service modules
    
    async def _execute_data_analysis_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
        """Execute data analysis task"""
        if task.type == TaskType.DATA_ANALYSIS:
            # Analyze graph patterns
            query = """
            MATCH (n)
            RETURN labels(n) as labels, count(n) as count
            ORDER BY count DESC
            LIMIT 10
            """
            
            results = await driver_instance.execute_query(query, database_="neo4j")
            
            patterns = []
            for record in results.records:
                labels = record["labels"]
                count = record["count"]
                if labels:
                    patterns.append(f"Found {count} nodes with label '{labels[0]}'")
            
            return {
                "patterns": patterns,
                "analysis": f"Analyzed {len(patterns)} node types",
                "timestamp": datetime.now().isoformat()
            }
        return {"error": "Unsupported task type for Data Analyst"}

    async def _execute_etl_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
        return {"status": "Mock ETL task executed", "task": task.model_dump()}

    async def _execute_query_planning_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
         return {"status": "Mock Query Planning task executed", "task": task.model_dump()}

    async def _execute_visualization_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
         return {"status": "Mock Visualization task executed", "task": task.model_dump()}
    
    async def _execute_quality_monitoring_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
         return {"status": "Mock Quality Monitoring task executed", "task": task.model_dump()}

    async def _execute_chat_coordination_task(self, task: AgenticTask, driver_instance: neo4j.AsyncDriver) -> Dict[str, Any]:
         return {"status": "Mock Chat Coordination task executed", "task": task.model_dump()}

    def get_system_status(self) -> SystemStatus:
        """Get current system status"""
        return SystemStatus(
            active_agents=list(self.agents.values()),
            task_queue_size=len(self.task_queue),
            system_health="healthy" if len([a for a in self.agents.values() if a.status == "ready"]) > 0 else "degraded",
            performance_metrics=self.system_metrics
        )

